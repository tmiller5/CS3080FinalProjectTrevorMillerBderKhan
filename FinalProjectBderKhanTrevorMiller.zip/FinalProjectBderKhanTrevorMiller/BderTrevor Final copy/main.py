"""
Bder Khan & Trevor Miller
CS 3080 Final, Pokemon Final Project
12/14/2020

This program simulates a small portion of the Pokemon game.
You will have a Pokemon that has been created by our AI.
The Pokemon in this program has been pre-generated as it takes a long time.
This program then generates random abilities and names for the Pokemon.
You will be able to battle one enemy that have been created by AI.
Once you have defeated the enemy, you will have beaten the game.

This program uses TKINTER for the GUI. It has interactive buttons to flow through the game.
"""

import tkinter
import os
from random import randint
from tkinter import ttk
from tkinter import *

# Setting the GUI parameters. Setting the window size and window title
window = tkinter.Tk()
window.title("Bder and Trevor's Pokemon")
window.geometry("907x577")
window.configure(bg='blue')

# setting file paths for background images
backgroundFilePath = os.path.abspath("background.gif")
background_image = tkinter.PhotoImage(file=backgroundFilePath)
background2FilePath = os.path.abspath("background1.gif")
background_image2 = tkinter.PhotoImage(file=background2FilePath)

# User pokemon image load (Loads at random, the pre generated pokemon by our AI)
user_image = os.path.abspath("userpoke" + str(randint(1, 10)) + ".gif")
user_poke = tkinter.PhotoImage(file=user_image)

# Enemy Pokemon image load (Only 1 enemy)
enemy_image = os.path.abspath("enemypoke1.gif")
enemy_poke = tkinter.PhotoImage(file=enemy_image)

# win/lose picture load
wincard = os.path.abspath("wincard.gif")
losecard = os.path.abspath("endcard.gif")
wincard_image = tkinter.PhotoImage(file=wincard)
losecard_image = tkinter.PhotoImage(file=losecard)

# Generating random pokemon names (First part of the name)
PokeFirstDict = {
    0: "Strai",
    1: "Eng",
    2: "Shu",
    3: "Mai",
    4: "Fel",
    5: "Iri",
    6: "Kri",
    7: "Te"
}
# Last part of the name
PokeLastDict = {
    0: "muds",
    1: "zein",
    2: "sad",
    3: "ieds",
    4: "gel",
    5: "gix",
    6: "deth",
    7: "rals"
}
# Pokemon healths that can be picked when the pokemon is generated
PokeHealth = {
    0: 105,
    1: 95,
    2: 115,
    3: 110,
    4: 120,
    5: 100
}
# 4 moves from this list will be given to the pokemon at random. Along with the corresponding damage rating
PokeMoves = {
    15: "Power Pulse",
    16: "Morning Star",
    17: "Canon Blast",
    18: "Spear Hook",
    19: "Tail Whoop",
    20: "Dragons Breath",
    21: "Rock Smash",
    22: "Whisper Whip",
    23: "Sand Burn",
    24: "Electric Strand"
}

# Creating user pokemon (name generation, health, 4 powers)
userPokeName = str(PokeFirstDict[randint(0, 7)] + str(PokeLastDict[randint(1, 8) - 1]))
userPokeHealth = PokeHealth[randint(0, 5)]
userMove1Power = randint(15, 24)
userMove1Text = PokeMoves[userMove1Power]
userMove2Power = randint(15, 24)
userMove2Text = PokeMoves[userMove2Power]
userMove3Power = randint(15, 24)
userMove3Text = PokeMoves[userMove3Power]
userMove4Power = randint(15, 24)
userMove4Text = PokeMoves[userMove4Power]

# Creating enemy pokemon 1 (name generation, health, 2 powers)
enemyPoke1Name = str(PokeFirstDict[randint(0, 7)] + str(PokeLastDict[randint(1, 8) - 1]))
enemyPokeHealth = 125
enemyMove1Power = randint(15, 24)
enemyMove1Text = PokeMoves[enemyMove1Power]
enemyMove2Power = randint(15, 24)
enemyMove2Text = PokeMoves[enemyMove2Power]

# Function that is activated once the user chooses a power to use
def damageClick(value):
    # Global variables for the pokemon healths
    global enemyPokeHealth
    temp1 = enemyPokeHealth
    global userPokeHealth
    temp2 = userPokeHealth

    # If statements for the four options the user gets from the attacks the pokemon can use
    # These correspond with the 'radiobox'
    if value == 1:
        # Lowering enemy and user health as the attacks come, also displaying all of that info on the GUI
        enemyPokeHealth = temp1 - userMove1Power
        user_attack_label = tkinter.Label(window, text=f"{userPokeName} used {userMove1Text}, {userMove1Power} damage")
        user_attack_label.place(x=100, y=350)
        enemy_health_label = tkinter.Label(window, text=f"{enemyPoke1Name}'s Health: {enemyPokeHealth}")
        enemy_health_label.place(x=800, y=150, anchor='center')
        userPokeHealth = temp2 - enemyMove1Power
        enemy_attack_label = tkinter.Label(window, text=f"{enemyPoke1Name} used {enemyMove1Text}", font=('courier', 20))
        enemy_attack_label.place(x=700, y=200, anchor='center')
        user_health_label = tkinter.Label(window, text=f"{userPokeName}'s Health: {userPokeHealth}").place(x=100, y=400)
        if userPokeHealth <= 0:
            losecard_label = tkinter.Label(window, image=losecard_image)
            losecard_label.place(x=0, y=0, relwidth=1, relheight=1)
        if enemyPokeHealth <= 0:
            wincard_label = tkinter.Label(window, image=wincard_image)
            wincard_label.place(x=0, y=0, relwidth=1, relheight=1)
    if value == 2:
        enemyPokeHealth = temp1 - userMove2Power
        user_attack_label = tkinter.Label(window, text=f"{userPokeName} used {userMove2Text}, {userMove2Power} damage")
        user_attack_label.place(x=100, y=350)
        enemy_health_label = tkinter.Label(window, text=f"{enemyPoke1Name}'s Health: {enemyPokeHealth}")
        enemy_health_label.place(x=800, y=150, anchor='center')
        userPokeHealth = temp2 - enemyMove2Power
        enemy_attack_label = tkinter.Label(window, text=f"{enemyPoke1Name} used {enemyMove2Text}", font=('courier', 20))
        enemy_attack_label.place(x=700, y=200, anchor='center')
        user_health_label = tkinter.Label(window, text=f"{userPokeName}'s Health: {userPokeHealth}").place(x=100, y=400)
        if userPokeHealth <= 0:
            losecard_label = tkinter.Label(window, image=losecard_image)
            losecard_label.place(x=0, y=0, relwidth=1, relheight=1)
        if enemyPokeHealth <= 0:
            wincard_label = tkinter.Label(window, image=wincard_image)
            wincard_label.place(x=0, y=0, relwidth=1, relheight=1)
    if value == 3:
        enemyPokeHealth = temp1 - userMove3Power
        user_attack_label = tkinter.Label(window, text=f"{userPokeName} used {userMove3Text}, {userMove3Power} damage")
        user_attack_label.place(x=100, y=350)
        enemy_health_label = tkinter.Label(window, text=f"{enemyPoke1Name}'s Health: {enemyPokeHealth}")
        enemy_health_label.place(x=800, y=150, anchor='center')
        userPokeHealth = temp2 - enemyMove1Power
        enemy_attack_label = tkinter.Label(window, text=f"{enemyPoke1Name} used {enemyMove1Text}", font=('courier', 20))
        enemy_attack_label.place(x=700, y=200, anchor='center')
        user_health_label = tkinter.Label(window, text=f"{userPokeName}'s Health: {userPokeHealth}").place(x=100, y=400)
        if userPokeHealth <= 0:
            losecard_label = tkinter.Label(window, image=losecard_image)
            losecard_label.place(x=0, y=0, relwidth=1, relheight=1)
        if enemyPokeHealth <= 0:
            wincard_label = tkinter.Label(window, image=wincard_image)
            wincard_label.place(x=0, y=0, relwidth=1, relheight=1)
    if value == 4:
        enemyPokeHealth = temp1 - userMove4Power
        user_attack_label = tkinter.Label(window, text=f"{userPokeName} used {userMove4Text}, {userMove4Power} damage")
        user_attack_label.place(x=100, y=350)
        enemy_health_label = tkinter.Label(window, text=f"{enemyPoke1Name}'s Health: {enemyPokeHealth}")
        enemy_health_label.place(x=800, y=150, anchor='center')
        userPokeHealth = temp2 - enemyMove2Power
        enemy_attack_label = tkinter.Label(window, text=f"{enemyPoke1Name} used {enemyMove2Text}", font=('courier', 20))
        enemy_attack_label.place(x=700, y=200, anchor='center')
        user_health_label = tkinter.Label(window, text=f"{userPokeName}'s Health: {userPokeHealth}").place(x=100, y=400)
        if userPokeHealth <= 0:
            losecard_label = tkinter.Label(window, image=losecard_image)
            losecard_label.place(x=0, y=0, relwidth=1, relheight=1)
        if enemyPokeHealth <= 0:
            wincard_label = tkinter.Label(window, image=wincard_image)
            wincard_label.place(x=0, y=0, relwidth=1, relheight=1)


# Start the first battle, once the button is selected form the user
def firstBattle():
    # Updating the background and hiding the previous screens buttons and labels
    background_label = tkinter.Label(window, image=background_image2)
    background_label.place(x=0, y=0, relwidth=1, relheight=1)
    userpic_label = tkinter.Label(window, image=user_poke)
    userpic_label.place(x=100, y=450, anchor='center')
    enemypic_label = tkinter.Label(window, image=enemy_poke)
    enemypic_label.place(x=800, y=100, anchor='center')

    # Radio button setup (corresponds with the if statements above)
    user_button = IntVar()
    ttk.Radiobutton(window, text=userMove1Text, variable=user_button, value=1, command=lambda: damageClick(1)).place(
        x=250, y=450, anchor='center')
    ttk.Radiobutton(window, text=userMove2Text, variable=user_button, value=2, command=lambda: damageClick(2)).place(
        x=380, y=450, anchor='center')
    ttk.Radiobutton(window, text=userMove3Text, variable=user_button, value=3, command=lambda: damageClick(3)).place(
        x=500, y=450, anchor='center')
    ttk.Radiobutton(window, text=userMove4Text, variable=user_button, value=4, command=lambda: damageClick(4)).place(
        x=620, y=450, anchor='center')

    user_health_label = tkinter.Label(window, text=f"{userPokeName}'s Health: {userPokeHealth}").place(x=100, y=400)

# This is the first button function.
def startClick():
    # Setting the new background and positioning buttons
    background_label = tkinter.Label(window, image=background_image)
    background_label.place(x=0, y=0, relwidth=1, relheight=1)
    startLabel.pack_forget()
    startButton1.pack_forget()
    knowPokeButton1 = ttk.Button(window, text="Ready For Battle!", command=firstBattle)
    knowPokeButton1.place(x=453, y=550, anchor='center')
    knowPokeLabel = tkinter.Label(window, text=f"Here is your Pokemon! It's name is {userPokeName}!",
                                  font=('Courier', 30))
    knowPokeLabel.place(x=453, y=25, anchor='center')
    userpic_label = tkinter.Label(window, image=user_poke)
    userpic_label.place(x=453, y=100, anchor='center')

    # Introducing user to the pokemon, showing the generated data and stats
    knowPokeLabel1 = tkinter.Label(window, text=f"{userPokeName} has {userPokeHealth}HP \n\n\n"
                                                f"{userPokeName} has 4 power moves: \n\n"
                                                f"{userMove1Text}: {userMove1Power} damage\n"
                                                f"{userMove2Text}: {userMove2Power} damage\n"
                                                f"{userMove3Text}: {userMove3Power} damage\n"
                                                f"{userMove4Text}: {userMove4Power} damage\n", font=('Courier', 20))
    knowPokeLabel1.place(x=453, y=300, anchor='center')


# The first popup window that explains a little bit about the game
startLabel = tkinter.Label(window, text='Welcome to Bder and Trevors Pokemon game!',
                           bg='blue', fg='white', font=('Courier', 25))
startLabel.place(relx=0.52, rely=0.1, anchor='center')

startLabel2 = tkinter.Label(window, text="""
This game simulates a small portion of the Pokemon game.\n
You will have a Pokemon that has been created by our AI.\n
The Pokemon in this program has been pre-generated as it takes a long time.\n
This program then generates random abilities and names for the Pokemon.\n
You will be able to battle one enemy that have been created by AI.\n
Once you have defeated the enemy, you will have beaten the game.

""", bg='blue', fg='white', font=('Courier', 17))
startLabel2.place(relx=0.52, rely=0.2, anchor='n')

# For this button, had to use 'ttk.Button..' so that text shows in the button on MacOS. Or else, text won't show
startButton1 = ttk.Button(window, text="Get To Know Your Pokemon!", command=startClick)
startButton1.place(x=453, y=550, anchor='center')


# Loop for the GUI
window.mainloop()
